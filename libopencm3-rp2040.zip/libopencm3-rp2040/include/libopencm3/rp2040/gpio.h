#pragma once

#include <libopencm3/rp2040/memorymap.h>
#include <libopencm3/cm3/common.h>

/** GPIO number definitions (for convenience) */
/* @defgroup gpio_pin_id GPIO Pin Identifiers
@ingroup gpio_defines

@{*/
#define GPIO0				(1 << 0)
#define GPIO1				(1 << 1)
#define GPIO2				(1 << 2)
#define GPIO3				(1 << 3)
#define GPIO4				(1 << 4)
#define GPIO5				(1 << 5)
#define GPIO6				(1 << 6)
#define GPIO7				(1 << 7)
#define GPIO8				(1 << 8)
#define GPIO9				(1 << 9)
#define GPIO10				(1 << 10)
#define GPIO11				(1 << 11)
#define GPIO12				(1 << 12)
#define GPIO13				(1 << 13)
#define GPIO14				(1 << 14)
#define GPIO15				(1 << 15)
#define GPIO16				(1 << 16)
#define GPIO17				(1 << 17)
#define GPIO18				(1 << 18)
#define GPIO19				(1 << 19)
#define GPIO20				(1 << 20)
#define GPIO21				(1 << 21)
#define GPIO22				(1 << 22)
#define GPIO23				(1 << 23)
#define GPIO24				(1 << 24)
#define GPIO25				(1 << 25)
#define GPIO26				(1 << 26)
#define GPIO27				(1 << 27)
#define GPIO28				(1 << 28)
#define GPIO29				(1 << 29)
#define GPIO30				(1 << 30)
#define GPIO31				(1 << 31)

/* @} */

/* GPIO function selection definitions */
/* @defgroup gpio_funcsel GPIO function selection 
 * @ingroup gpio_defines
 *
@{*/

#define GPIO_F0				0
#define GPIO_F1				1
#define GPIO_F2				2
#define GPIO_F3				3
#define GPIO_F4				4
#define GPIO_F5				5
#define GPIO_F6				6
#define GPIO_F7				7
#define GPIO_F8				8
#define GPIO_F9				9

/* @} */

/** GPIO pin status register
 * @param bank register bank operated on, see @ref gpio_register_bank
 * @param gpio gpio number
 * @note QSPI bank can be operated safely only if XIP is not used (i.e. you are executing out of RAM)
 */
#define GPIO_STATUS(bank, gpio)	\
							MMIO32(IO_BANK0_BASE + ((bank) * (IO_QSPI_BASE - IO_BANK0_BASE)) + ((gpio) * 0x8))
/** GPIO pin control register
 * @param bank register bank operated on, see @ref gpio_register_bank
 * @param gpio gpio number
 * @note QSPI bank can be operated safely only if XIP is not used (i.e. you are executing out of RAM)
 */
#define GPIO_CTRL(bank, gpio) \
							MMIO32(IO_BANK0_BASE + ((bank) * (IO_QSPI_BASE - IO_BANK0_BASE)) + ((gpio) * 0x8) + 0x4)

/* Function selection within GPIO_CTRLx register */
#define GPIO_FUNCSEL_SHIFT	0
#define GPIO_FUNCSEL_MASK	0x1F

/** Raw interrupt access register
 * This macro returns GPIO_INTRx register, which contains interrupt access bits for GPIO `gpio`.
 * Every GPIO contains a packed 4-bit section, whose offset can be calculated as `(gpio % 8) * 4`
 * @param gpio GPIO pin number
 **/
#define GPIO_INTR(gpio)		MMIO32(IO_BANK0_BASE + 0x0F0 + ((gpio / 8) * 0x4))

/** Interrupt enable access register */
#define GPIO_INTE(proc, gpio) \
							MMIO32(IO_BANK0_BASE + 0x100 + (proc * 0x30) + ((gpio / 8) * 0x4))

/** Interrupt force register */
#define GPIO_INTF(proc, gpio) \
							MMIO32(IO_BANK0_BASE + 0x110 + (proc * 0x30) + ((gpio / 8) * 0x4))

/** Interrupt status register */
#define GPIO_INTS(proc, gpio) \
							MMIO32(IO_BANK0_BASE + 0x120 + (proc * 0x30) + ((gpio / 8) * 0x4))

/** Dormant wake up interrupt enable register */
#define GPIO_DORMANT_WAKE_INTE(gpio) \
							MMIO32(IO_BANK0_BASE + 0x160 + ((gpio / 8) * 0x4))

/** Dormant wake up interrupt force register */
#define GPIO_DORMANT_WAKE_INTF(gpio) \
							MMIO32(IO_BANK0_BASE + 0x170 + ((gpio / 8) * 0x4))

/** Dormant wake up interrupt status register */
#define GPIO_DORMANT_WAKE_INTS(gpio) \
							MMIO32(IO_BANK0_BASE + 0x180 + ((gpio / 8) * 0x4))

/** GPIO register banks.
 * RP2040 has two GPIO banks. One of them is dedicated for user GPIO,
 * another's primary use is QSPI attachment, but in certain cases, such as
 * execution from RAM, it can be used for GPIO too.
 * @defgroup gpio_register_bank
 * @ingroup gpio_defines
@{ */
#define GPIO_BANK0			0
#define GPIO_QSPI			1

/* @} */

/** GPIO input value register */
#define GPIO_IN(bank)			MMIO32(SIO_BASE + 0x004 + (bank) * 0x004)

/** Convenience definition for accessing QSPI input value register */
#define GPIO_HI_IN				GPIO_IN(GPIO_QSPI)

/** GPIO direct output manipulation register */ 
#define GPIO_OUT(bank)			MMIO32(SIO_BASE + 0x010 + (bank) * 0x020)

/** GPIO direct setting register */
#define GPIO_OUT_SET(bank)		MMIO32(SIO_BASE + 0x014 + (bank) * 0x020)

/** GPIO direct clearing register */
#define GPIO_OUT_CLR(bank)		MMIO32(SIO_BASE + 0x018 + (bank) * 0x020)

/** GPIO direct toggling register */
#define GPIO_OUT_XOR(bank)		MMIO32(SIO_BASE + 0x01C + (bank) * 0x020)

/** GPIO output enable register */
#define GPIO_OE(bank)			MMIO32(SIO_BASE + 0x020 + (bank) * 0x020)

/** GPIO activate output enable register */
#define GPIO_OE_SET(bank)		MMIO32(SIO_BASE + 0x024 + ((bank) * 0x020))

/** GPIO deactivate output enable register */
#define GPIO_OE_CLR(bank)		MMIO32(SIO_BASE + 0x028 + (bank) * 0x020)

/** GPIO toggle output enable register */
#define GPIO_OE_XOR(bank)		MMIO32(SIO_BASE + 0x02C + (bank) * 0x020)

#define GPIO_HI_OUT				GPIO_OUT(GPIO_QSPI)
#define GPIO_HI_OUT_SET			GPIO_OUT_SET(GPIO_QSPI)
#define GPIO_HI_OUT_CLR			GPIO_OUT_CLR(GPIO_QSPI)
#define GPIO_HI_OUT_XOR			GPIO_OUT_XOR(GPIO_QSPI)
#define GPIO_HI_OE				GPIO_OE(GPIO_QSPI)
#define GPIO_HI_OE_SET			GPIO_OE_SET(GPIO_QSPI)
#define GPIO_HI_OE_CLR			GPIO_OE_CLR(GPIO_QSPI)
#define GPIO_HI_OE_XOR			GPIO_OE_XOR(GPIO_QSPI)

									
/** GPIO pin configuration register */
#define GPIO_GPIO(bank, gpio)	MMIO32(PADS_BANK0_BASE + 0x4 + \
								((bank) * (PADS_QSPI_BASE - PADS_BANK0_BASE)) \
								+ ((gpio) * 0x4))

/** GPIO pin output disable flag */
#define GPIO_GPIO_OD			(1 << 7)

/** GPIO pin input enable flag */
#define GPIO_GPIO_IE			(1 << 6)

/** GPIO pin drive strength field in GPIO configuration register */
#define GPIO_DRIVE_SHIFT		4
#define GPIO_DRIVE_MASK			0x3

/** GPIO pin drive strength definitions.
 * @defgroup gpio_pin_strenght
 * @ingroup gpio_defines
@{ */

#define GPIO_DRIVE_2MA			0
#define GPIO_DRIVE_4MA			1
#define GPIO_DRIVE_8MA			2
#define GPIO_DRIVE_12MA			3

/* @} */

/** GPIO pin pullup/pulldown field in GPIO configuration register */
#define GPIO_PUPD_SHIFT			2
#define GPIO_PUPD_MASK			0x3

/** GPIO pullup/pulldown definitions.
 * @defgroup gpio_pupd
 * @ingroup gpio_defines
@{ */

#define GPIO_PUPD_NONE			0
#define GPIO_PUPD_PDE			1
#define GPIO_PUPD_PUE			2
#define GPIO_PUPD_BOTH			3

/* @} */

/** GPIO pin enable Schmitt trigger.
 * You want to disable Schmitt for analog operation.
 */
#define GPIO_GPIO_SCHMITT		(1 << 1)

/** GPIO pin fast slew rate.
 * If unset, slow slew rate applies.
 */
#define GPIO_GPIO_SLEWFAST		(1 << 0)

/** Convenience alias for fast GPIO slew rate */
#define GPIO_SPEED_FAST			GPIO_GPIO_SLEWFAST

/** Convenience alias for slow GPIO slew rate */
#define GPIO_SPEED_FLOW			0

/** GPIO operation mode.
 * These are some predefined operation modes for GPIO pin.
 * @defgroup gpio_mode
 * @ingroup gpio_defines
@{ */

#define GPIO_MODE_INPUT			0
#define GPIO_MODE_OUTPUT		1
#define GPIO_MODE_ANALOG		2
#define GPIO_MODE_AF			3

/* @} */

BEGIN_DECLS

void gpio_set(unsigned gpiobank, uint32_t gpios);
void gpio_clear(unsigned gpiobank, uint32_t gpios);
uint16_t gpio_get(unsigned gpiobank, uint32_t gpios);
void gpio_toggle(unsigned gpiobank, uint32_t gpios);
uint32_t gpio_port_read(unsigned gpiobank);
void gpio_port_write(unsigned gpiobank, uint32_t data);
void gpio_mode_setup(unsigned gpiobank, uint8_t mode, uint8_t pull_up_down,
		     uint32_t gpios);
void gpio_set_output_options(unsigned gpiobank, uint8_t drive, uint8_t speed,
			     uint32_t gpios);
void gpio_set_af(unsigned gpiobank, uint8_t alt_func_num, uint32_t gpios);

END_DECLS

