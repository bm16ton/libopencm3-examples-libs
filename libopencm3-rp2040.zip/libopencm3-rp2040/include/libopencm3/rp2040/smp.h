#pragma once

#include <libopencm3/rp2040/memorymap.h>
#include <libopencm3/cm3/common.h>
#include <stdbool.h>

#define SMP_CPUID				MMIO32(SIO_BASE + 0x0)

/** SMP FIFO status register */
#define SMP_FIFO_ST				MMIO32(SIO_BASE + 0x050)

/** Sticky error flag indicating that FIFO was read, while empty */
#define SMP_FIFO_ST_ROE			(1 << 3)

/** Sticky error flag indicating that FIFO was written, while full */
#define SMP_FIFO_ST_WOF			(1 << 2)

/** Core Tx FIFO is not full and can accept more data */
#define SMP_FIFO_ST_RDY			(1 << 1)

/** Core Rx FIFO contains valid data */
#define SMP_FIFO_ST_VLD			(1 << 0)

/** SMP FIFO write register */
#define SMP_FIFO_WR				MMIO32(SIO_BASE + 0x054)

/** SMP FIFO read register */
#define SMP_FIFO_RD				MMIO32(SIO_BASE + 0x058)

/** SMP spinlock status register */
#define SMP_SPINLOCK_ST			MMIO32(SIO_BASE + 0x05C)

/** SMP spinlock access register */
#define SMP_SPINLOCK(id)		MMIO32(SIO_BASE + 0x100 + ((id) * 0x4))

BEGIN_DECLS

unsigned smp_spinlock_trylock(unsigned spinlock);
void smp_spinlock_lock(unsigned spinlock);
void smp_spinlock_unlock(unsigned spinlock);

bool smp_fifo_ready(void);
bool smp_fifo_free(void);

void smp_fifo_write(uint32_t data);
uint32_t smp_fifo_read(void);

uint32_t smp_coreid(void);

void smp_reset_cpu1(void);
bool smp_boot_cpu1(void (*entry)(void), uint32_t * sp, uint32_t vector_table);

END_DECLS
