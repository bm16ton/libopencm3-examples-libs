#pragma once

#include <libopencm3/rp2040/memorymap.h>
#include <libopencm3/cm3/common.h>

#define RESETS_RESET			MMIO32(RESETS_BASE + 0x00)
#define RESETS_WDSEL			MMIO32(RESETS_BASE + 0x04)
#define RESETS_RESET_DONE		MMIO32(RESETS_BASE + 0x08)

#define RESETS_USBCTRL			(1 << 24)
#define RESETS_UART1			(1 << 23)
#define RESETS_UART0			(1 << 22)
#define RESETS_TIMER			(1 << 21)
#define RESETS_TBMAN			(1 << 20)
#define RESETS_SYSINFO			(1 << 19)
#define RESETS_SYSCFG			(1 << 18)
#define RESETS_SPI1				(1 << 17)
#define RESETS_SPI0				(1 << 16)
#define RESETS_RTC				(1 << 15)
#define RESETS_PWM				(1 << 14)
#define RESETS_PLL_USB			(1 << 13)
#define RESETS_PLL_SYS			(1 << 12)
#define RESETS_PIO1				(1 << 11)
#define RESETS_PIO0				(1 << 10)
#define RESETS_PADS_QSPI		(1 << 9)
#define RESETS_PADS_BANK0		(1 << 8)
#define RESETS_JTAG				(1 << 7)
#define RESETS_IO_QSPI			(1 << 6)
#define RESETS_IO_BANK0			(1 << 5)
#define RESETS_I2C1				(1 << 4)
#define RESETS_I2C0				(1 << 3)
#define RESETS_DMA				(1 << 2)
#define RESETS_BUSCTRL			(1 << 1)
#define RESETS_ADC				(1 << 0)

BEGIN_DECLS

void reset_periph_hold(uint32_t peripherals);
void reset_periph_release(uint32_t peripherals);
void reset_periph_pulse(uint32_t peripherals);

void reset_watchdog_enable(uint32_t peripherals);
void reset_watchdog_disable(uint32_t peripherals);

void reset_periph_wait(uint32_t peripherals);

END_DECLS
