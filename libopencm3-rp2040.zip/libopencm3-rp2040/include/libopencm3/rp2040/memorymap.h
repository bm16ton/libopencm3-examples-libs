/** @defgroup mmap_defines Memory Map
 *
 * @brief <b>Defined Constants for the SWM050 Memory Map</b>
 *
 * @ingroup SWM050_defines
 *
 * LGPL License Terms @ref lgpl_license
 */
/*
 * This file is part of the libopencm3 project.
 *
 * Copyright (C) 2019 Icenowy Zheng <icenowy@aosc.io>
 *
 * This library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */
/**@{*/
#ifndef LIBOPENCM3_MEMORYMAP_H
#define LIBOPENCM3_MEMORYMAP_H

#include <libopencm3/cm3/memorymap.h>

/* Memory map for all buses */
/** @defgroup memory_map Memory Map for All Buses
@{*/
#define PERIPH_BASE			(0x40000000U)
#define PERIPH_BASE_APB		(PERIPH_BASE)
#define PERIPH_BASE_AHB		(PERIPB_BASE + 0x10000000U)

/* Register boundary addresses */

/* APB peripherals */

#define SYSINFO_BASE				(PERIPH_BASE_APB + 0x00000)
#define SYSCFG_BASE					(PERIPH_BASE_APB + 0x04000)
#define CLOCKS_BASE					(PERIPH_BASE_APB + 0x08000)
#define RESETS_BASE					(PERIPH_BASE_APB + 0x0C000)
#define PSM_BASE					(PERIPH_BASE_APB + 0x10000)
#define IO_BANK0_BASE				(PERIPH_BASE_APB + 0x14000)
#define IO_QSPI_BASE				(PERIPH_BASE_APB + 0x18000)
#define PADS_BANK0_BASE				(PERIPH_BASE_APB + 0x1C000)
#define PADS_QSPI_BASE				(PERIPH_BASE_APB + 0x20000)
#define XOSC_BASE					(PERIPH_BASE_APB + 0x24000)
#define PLL_SYS_BASE				(PERIPH_BASE_APB + 0x28000)
#define PLL_USB_BASE				(PERIPH_BASE_APB + 0x2C000)
#define BUSCTRL_BASE				(PERIPH_BASE_APB + 0x30000)
#define UART0_BASE					(PERIPH_BASE_APB + 0x34000)
#define UART1_BASE					(PERIPH_BASE_APB + 0x38000)
#define SPI0_BASE					(PERIPH_BASE_APB + 0x3C000)
#define SPI1_BASE					(PERIPH_BASE_APB + 0x40000)
#define I2C0_BASE					(PERIPH_BASE_APB + 0x44000)
#define I2C1_BASE					(PERIPH_BASE_APB + 0x48000)
#define ADC_BASE					(PERIPH_BASE_APB + 0x4C000)
#define PWM_BASE					(PERIPH_BASE_APB + 0x50000)
#define TIMER_BASE					(PERIPH_BASE_APB + 0x54000)
#define WATCHDOG_BASE				(PERIPH_BASE_APB + 0x58000)
#define RTC_BASE					(PERIPH_BASE_APB + 0x5C000)
#define ROSC_BASE					(PERIPH_BASE_APB + 0x60000)
#define VREG_AND_CHIP_RESET_BASE	(PERIPH_BASE_APB + 0x64000)
#define TBMAN_BASE					(PERIPH_BASE_APB + 0x68000)

/* AHB-Lite peripherals */

#define DMA_BASE					(PERIPH_BASE_AHB + 0x00000)
#define USBCTRL_BASE				(PERIPH_BASE_AHB + 0x100000)
#define PIO0_BASE					(PERIPH_BASE_AHB + 0x200000)
#define PIO1_BASE					(PERIPH_BASE_AHB + 0x300000)
#define XIP_AUX_BASE				(PERIPH_BASE_AHB + 0x400000)

/* IOPORT peripherals */

#define SIO_BASE					0xD0000000U

/*@}*/

#endif
/**@}*/
